# InundationMapSD2
Project Submission for SD2

Group Details:

Name                                          Roll No.                      GR No.

1.Prasenjit Hiwale                            223068                        21820099
2.Shubham Patil                               223074                        21820152
3.Vipul Lodha                                 223065                        2182
4.Snehal Gunjal                               223070                        2182


